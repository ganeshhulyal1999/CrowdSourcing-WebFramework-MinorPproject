<footer>
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>Copyright &copy; IHDS</p>
                </div>
            </div>
        </footer>
 </div> <!-- /container -->


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/myscript.js"></script>
  </body>
</html>